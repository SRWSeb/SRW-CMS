<?php
  require "header.php";

$champCtrl = new ChampCtrl();

$results = $champCtrl->buildLeaguesArray();

var_export($results);



  require "footer.php";
?>
